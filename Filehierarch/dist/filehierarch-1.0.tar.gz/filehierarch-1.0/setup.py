from setuptools import setup


setup(name='filehierarch',
     version='1.0',
     description='A simpole filetree printer',
     author='isaactfa',
     author_email='isaacthefallenapple@gmail.com',
     packages=['filehierarch'])

