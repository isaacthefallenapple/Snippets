from setuptools import setup


setup(name='loadingbar',
     version='1.0',
     description='A small tool to create a command line style loadingbar',
     author='isaactfa',
     author_email='isaacthefallenapple@gmail.com',
     packages=['loadingbar'])

